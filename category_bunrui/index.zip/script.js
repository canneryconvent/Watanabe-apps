// IndexedDB ストレージ管理
const DB_NAME = 'CategoryClassifyDB';
const DB_VERSION = 2;
let db = null;

function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains('config')) {
        database.createObjectStore('config', { keyPath: 'key' });
      }
      if (!database.objectStoreNames.contains('categories')) {
        database.createObjectStore('categories', { keyPath: 'id', autoIncrement: true });
      }
      if (!database.objectStoreNames.contains('items')) {
        database.createObjectStore('items', { keyPath: 'id', autoIncrement: true });
      }
      if (!database.objectStoreNames.contains('history')) {
        database.createObjectStore('history', { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = (e) => {
      db = e.target.result;
      resolve();
    };
    request.onerror = (e) => reject(e);
  });
}

function dbGetStore(storeName) {
  return new Promise((resolve) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
  });
}

function dbSaveStore(storeName, items) {
  return new Promise((resolve) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.clear().onsuccess = () => {
      let remaining = items.length;
      if (remaining === 0) resolve();
      items.forEach(item => {
        store.put(item).onsuccess = () => {
          remaining--;
          if (remaining === 0) resolve();
        };
      });
    };
  });
}

function dbAddHistory(entry) {
  return new Promise((resolve) => {
    const tx = db.transaction('history', 'readwrite');
    const store = tx.objectStore('history');
    store.add(entry).onsuccess = () => resolve();
  });
}

function dbClearHistory() {
  return new Promise((resolve) => {
    const tx = db.transaction('history', 'readwrite');
    const store = tx.objectStore('history');
    store.clear().onsuccess = () => resolve();
  });
}

// 初期データ
const defaultCategories = [
  { id: 1, name: "やさい", color: "#d4edda", icon: "", enabled: true },
  { id: 2, name: "くだもの", color: "#ffe8d6", icon: "", enabled: true },
  { id: 3, name: "のりもの", color: "#d0ebff", icon: "", enabled: true },
  { id: 4, name: "どうぶつ", color: "#fce8e6", icon: "", enabled: true },
  { id: 5, name: "たべもの", color: "#fff3bf", icon: "", enabled: true },
  { id: 6, name: "うみのいきもの", color: "#e7f5ff", icon: "", enabled: true },
  { id: 7, name: "むし", color: "#e6fcf5", icon: "", enabled: true }
];

const defaultItems = [
  // やさい
  { name: "トマト", type: "emoji", value: "🍅", tags: ["やさい"] },
  { name: "なす", type: "emoji", value: "🍆", tags: ["やさい"] },
  { name: "とうもろこし", type: "emoji", value: "🌽", tags: ["やさい"] },
  { name: "ブロッコリー", type: "emoji", value: "🥦", tags: ["やさい"] },
  { name: "にんじん", type: "emoji", value: "🥕", tags: ["やさい"] },
  { name: "じゃがいも", type: "emoji", value: "🥔", tags: ["やさい"] },
  { name: "さつまいも", type: "emoji", value: "🍠", tags: ["やさい"] },
  { name: "えだまめ", type: "emoji", value: "🫛", tags: ["やさい"] },
  { name: "ピーマン", type: "emoji", value: "🫑", tags: ["やさい"] },
  { name: "たまねぎ", type: "emoji", value: "🧅", tags: ["やさい"] },
  { name: "にんにく", type: "emoji", value: "🧄", tags: ["やさい"] },
  { name: "きゅうり", type: "emoji", value: "🥒", tags: ["やさい"] },

  // くだもの
  { name: "りんご", type: "emoji", value: "🍎", tags: ["くだもの"] },
  { name: "いちご", type: "emoji", value: "🍓", tags: ["くだもの"] },
  { name: "バナナ", type: "emoji", value: "🍌", tags: ["くだもの"] },
  { name: "ぶどう", type: "emoji", value: "🍇", tags: ["くだもの"] },
  { name: "みかん", type: "emoji", value: "🍊", tags: ["くだもの"] },
  { name: "すいか", type: "emoji", value: "🍉", tags: ["くだもの"] },
  { name: "もも", type: "emoji", value: "🍑", tags: ["くだもの"] },
  { name: "メロン", type: "emoji", value: "🍈", tags: ["くだもの"] },
  { name: "パイナップル", type: "emoji", value: "🍍", tags: ["くだもの"] },
  { name: "キウイ", type: "emoji", value: "🥝", tags: ["くだもの"] },
  { name: "さくらんぼ", type: "emoji", value: "🍒", tags: ["くだもの"] },
  { name: "レモン", type: "emoji", value: "🍋", tags: ["くだもの"] },

  // のりもの
  { name: "くるま", type: "emoji", value: "🚗", tags: ["のりもの"] },
  { name: "バス", type: "emoji", value: "🚌", tags: ["のりもの"] },
  { name: "でんしゃ", type: "emoji", value: "🚃", tags: ["のりもの"] },
  { name: "しんかんせん", type: "emoji", value: "🚅", tags: ["のりもの"] },
  { name: "きゅうきゅうしゃ", type: "emoji", value: "🚑", tags: ["のりもの"] },
  { name: "しょうぼうしゃ", type: "emoji", value: "🚒", tags: ["のりもの"] },
  { name: "パトカー", type: "emoji", value: "🚓", tags: ["のりもの"] },
  { name: "ひこうき", type: "emoji", value: "✈️", tags: ["のりもの"] },
  { name: "ロケット", type: "emoji", value: "🚀", tags: ["のりもの"] },
  { name: "ヘリコプター", type: "emoji", value: "🚁", tags: ["のりもの"] },
  { name: "ふね", type: "emoji", value: "🚢", tags: ["のりもの"] },
  { name: "じてんしゃ", type: "emoji", value: "🚲", tags: ["のりもの"] },
  { name: "トラクター", type: "emoji", value: "🚜", tags: ["のりもの"] },

  // どうぶつ
  { name: "ねこ", type: "emoji", value: "🐱", tags: ["どうぶつ"] },
  { name: "いぬ", type: "emoji", value: "🐶", tags: ["どうぶつ"] },
  { name: "うさぎ", type: "emoji", value: "🐰", tags: ["どうぶつ"] },
  { name: "くま", type: "emoji", value: "🐻", tags: ["どうぶつ"] },
  { name: "パンダ", type: "emoji", value: "🐼", tags: ["どうぶつ"] },
  { name: "らいおん", type: "emoji", value: "🦁", tags: ["どうぶつ"] },
  { name: "ぞう", type: "emoji", value: "🐘", tags: ["どうぶつ"] },
  { name: "きりん", type: "emoji", value: "🦒", tags: ["どうぶつ"] },
  { name: "さる", type: "emoji", value: "🐵", tags: ["どうぶつ"] },
  { name: "コアラ", type: "emoji", value: "🐨", tags: ["どうぶつ"] },
  { name: "とら", type: "emoji", value: "🐯", tags: ["どうぶつ"] },
  { name: "ぶた", type: "emoji", value: "🐷", tags: ["どうぶつ"] },
  { name: "きつね", type: "emoji", value: "🦊", tags: ["どうぶつ"] },

  // たべもの
  { name: "おにぎり", type: "emoji", value: "🍙", tags: ["たべもの"] },
  { name: "パン", type: "emoji", value: "🍞", tags: ["たべもの"] },
  { name: "ピザ", type: "emoji", value: "🍕", tags: ["たべもの"] },
  { name: "ハンバーガー", type: "emoji", value: "🍔", tags: ["たべもの"] },
  { name: "ポテト", type: "emoji", value: "🍟", tags: ["たべもの"] },
  { name: "ソフトクリーム", type: "emoji", value: "🍦", tags: ["たべもの"] },
  { name: "ケーキ", type: "emoji", value: "🍰", tags: ["たべもの"] },
  { name: "ラーメン", type: "emoji", value: "🍜", tags: ["たべもの"] },
  { name: "おすし", type: "emoji", value: "🍣", tags: ["たべもの"] },
  { name: "カレー", type: "emoji", value: "🍛", tags: ["たべもの"] },
  { name: "ドーナツ", type: "emoji", value: "🍩", tags: ["たべもの"] },
  { name: "エビフライ", type: "emoji", value: "🍤", tags: ["たべもの"] },

  // うみのいきもの
  { name: "さかな", type: "emoji", value: "🐟", tags: ["うみのいきもの"] },
  { name: "たこ", type: "emoji", value: "🐙", tags: ["うみのいきもの"] },
  { name: "いか", type: "emoji", value: "🦑", tags: ["うみのいきもの"] },
  { name: "かに", type: "emoji", value: "🦀", tags: ["うみのいきもの"] },
  { name: "えび", type: "emoji", value: "🦐", tags: ["うみのいきもの"] },
  { name: "くじら", type: "emoji", value: "🐳", tags: ["うみのいきもの"] },
  { name: "いるか", type: "emoji", value: "🐬", tags: ["うみのいきもの"] },
  { name: "さめ", type: "emoji", value: "🦈", tags: ["うみのいきもの"] },
  { name: "かめ", type: "emoji", value: "🐢", tags: ["うみのいきもの"] },
  { name: "アザラシ", type: "emoji", value: "🦭", tags: ["うみのいきもの"] },
  { name: "クラゲ", type: "emoji", value: "🪼", tags: ["うみのいきもの"] },
  { name: "かい", type: "emoji", value: "🐚", tags: ["うみのいきもの"] },

  // むし・その他
  { name: "はち", type: "emoji", value: "🐝", tags: ["むし"] },
  { name: "てんとうむし", type: "emoji", value: "🐞", tags: ["むし"] },
  { name: "ちょうちょう", type: "emoji", value: "🦋", tags: ["むし"] },
  { name: "あおむし", type: "emoji", value: "🐛", tags: ["むし"] },
  { name: "アリ", type: "emoji", value: "🐜", tags: ["むし"] },
  { name: "かたつむり", type: "emoji", value: "🐌", tags: ["むし"] }
];

let appState = {
  config: {
    categoryCount: 2,          // カテゴリーの数
    maxVisibleItems: 3,        // 画面に同時に出る画像数
    totalItemsPerQuestion: 8,  // １問の画像数
    questionCount: 3,          // 問題数（最大20）
    showHomeButton: true       // おわる/もどるボタン表示
  },
  categories: [],
  items: []
};

// ゲーム進行状態
let currentGame = {
  currentQuestionIndex: 1,
  totalQuestions: 3,
  activeCategories: [],
  remainingQueue: [],
  activeOnScreen: [],
  completedCount: 0,
  targetTotalCount: 0,
  sessionMistakes: 0,
  sessionTotalPlaced: 0
};

// 音響エフェクト
let audioCtx = null;
function playSound(type) {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const now = audioCtx.currentTime;

  if (type === 'success') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.frequency.setValueAtTime(523.25, now);
    osc.frequency.setValueAtTime(659.25, now + 0.08);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.start(now); osc.stop(now + 0.3);
  } else if (type === 'error') {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.start(now); osc.stop(now + 0.2);
  } else if (type === 'clear') {
    [523.25, 659.25, 783.99, 1046.50].forEach((f, i) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.frequency.setValueAtTime(f, now + i * 0.1);
      gain.gain.setValueAtTime(0.2, now + i * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.3);
      osc.start(now + i * 0.1); osc.stop(now + i * 0.1 + 0.3);
    });
  }
}

// カテゴリーアイコン要素生成
function createCategoryIconElement(cat) {
  const container = document.createElement('div');
  container.style.cssText = `
    width: 44px;
    height: 44px;
    border-radius: 8px;
    background-color: ${cat.color || '#fff'};
    border: 1px solid rgba(0,0,0,0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    flex-shrink: 0;
  `;

  if (cat.icon) {
    const img = document.createElement('img');
    img.src = cat.icon;
    img.style.cssText = 'width: 100%; height: 100%; object-fit: contain;';
    container.appendChild(img);
    return container;
  }

  const catItems = appState.items.filter(item => item.tags.includes(cat.name)).slice(0, 3);
  const posStyles = [
    'top: 2px; left: 50%; transform: translateX(-50%); font-size: 16px;',
    'bottom: 2px; left: 3px; font-size: 16px;',
    'bottom: 2px; right: 3px; font-size: 16px;'
  ];

  catItems.forEach((item, idx) => {
    const el = document.createElement('div');
    el.style.cssText = `position: absolute; line-height: 1; ${posStyles[idx]}`;

    if (item.type === 'image') {
      const img = document.createElement('img');
      img.src = item.value;
      img.style.cssText = 'width: 16px; height: 16px; object-fit: contain;';
      el.appendChild(img);
    } else {
      el.textContent = item.value;
    }
    container.appendChild(el);
  });

  return container;
}

// データロード/セーブ
async function loadData() {
  await initDB();
  const cats = await dbGetStore('categories');
  const items = await dbGetStore('items');
  const configs = await dbGetStore('config');

  appState.categories = cats.length ? cats : [...defaultCategories];
  appState.items = items.length ? items : [...defaultItems];

  if (configs.length) {
    configs.forEach(c => { appState.config[c.key] = c.value; });
  }

  if (!cats.length) await dbSaveStore('categories', appState.categories);
  if (!items.length) await dbSaveStore('items', appState.items);

  updateConfigUI();
}

async function saveData() {
  await dbSaveStore('categories', appState.categories);
  await dbSaveStore('items', appState.items);
  const cfgItems = Object.keys(appState.config).map(k => ({ key: k, value: appState.config[k] }));
  await dbSaveStore('config', cfgItems);
}

// ゲーム開始・進行
document.getElementById('btn-start').addEventListener('click', () => {
  startNewSession();
});

document.getElementById('btn-home').addEventListener('click', () => {
  returnToHome();
});

function returnToHome() {
  document.getElementById('screen-game').classList.add('hidden');
  document.getElementById('screen-start').classList.remove('hidden');
}

function startNewSession() {
  currentGame.currentQuestionIndex = 1;
  currentGame.totalQuestions = appState.config.questionCount;
  currentGame.sessionMistakes = 0;
  currentGame.sessionTotalPlaced = 0;

  document.getElementById('screen-start').classList.add('hidden');
  document.getElementById('screen-game').classList.remove('hidden');

  setupSingleQuestion();
}

function setupSingleQuestion() {
  const oldBtn = document.querySelector('.next-btn-container');
  if (oldBtn) oldBtn.remove();

  const enabledCats = appState.categories.filter(c => c.enabled);
  if (enabledCats.length < 2) {
    alert("カテゴリーを2つ以上有効に設定してください。");
    returnToHome();
    return;
  }

  const shuffledCats = [...enabledCats].sort(() => Math.random() - 0.5);
  currentGame.activeCategories = shuffledCats.slice(0, appState.config.categoryCount);

  const activeNames = currentGame.activeCategories.map(c => c.name);
  const matchedItems = appState.items.filter(item => item.tags.some(t => activeNames.includes(t)));

  if (matchedItems.length === 0) {
    alert("選ばれたカテゴリーに対応するイラストがありません。");
    returnToHome();
    return;
  }

  const shuffledItems = [...matchedItems].sort(() => Math.random() - 0.5);
  const maxPerQ = appState.config.totalItemsPerQuestion;
  const targetNum = maxPerQ === 0 ? shuffledItems.length : Math.min(maxPerQ, shuffledItems.length);

  currentGame.remainingQueue = shuffledItems.slice(0, targetNum);
  currentGame.completedCount = 0;
  currentGame.targetTotalCount = currentGame.remainingQueue.length;
  currentGame.activeOnScreen = [];

  renderGameBaseUI();
  fillSpawnArea();
}

function renderGameBaseUI() {
  const btnHome = document.getElementById('btn-home');
  if (appState.config.showHomeButton) {
    btnHome.classList.remove('hidden');
  } else {
    btnHome.classList.add('hidden');
  }

  document.getElementById('question-display').textContent = `だい ${currentGame.currentQuestionIndex} / ${currentGame.totalQuestions} 問`;
  document.getElementById('progress-display').textContent = `${currentGame.completedCount} / ${currentGame.targetTotalCount}`;

  const targetZones = document.getElementById('target-zones');
  targetZones.innerHTML = '';

  currentGame.activeCategories.forEach(cat => {
    const zone = document.createElement('div');
    zone.className = 'target-zone';
    zone.dataset.category = cat.name;
    zone.style.backgroundColor = cat.color;

    const title = document.createElement('div');
    title.className = 'zone-title';

    const iconEl = createCategoryIconElement(cat);
    const label = document.createElement('span');
    label.textContent = cat.name;

    title.appendChild(iconEl);
    title.appendChild(label);

    const itemsBox = document.createElement('div');
    itemsBox.className = 'zone-items';

    zone.appendChild(title);
    zone.appendChild(itemsBox);
    targetZones.appendChild(zone);
  });

  document.getElementById('spawn-area').innerHTML = '';
}

function fillSpawnArea() {
  const spawnArea = document.getElementById('spawn-area');
  const needed = appState.config.maxVisibleItems - currentGame.activeOnScreen.length;

  // 画面下部の空きエリア（マージン）
  const BOTTOM_PADDING = 80;

  for (let i = 0; i < needed; i++) {
    if (currentGame.remainingQueue.length === 0) break;

    const itemData = currentGame.remainingQueue.shift();
    currentGame.activeOnScreen.push(itemData);

    const itemEl = document.createElement('div');
    itemEl.className = 'drag-item';

    if (itemData.type === 'image') {
      itemEl.innerHTML = `<img class="drag-content-img" src="${itemData.value}">`;
    } else {
      itemEl.innerHTML = `<div class="drag-content-emoji">${itemData.value}</div>`;
    }

    const rect = spawnArea.getBoundingClientRect();
    const maxX = Math.max(10, (rect.width || 600) - 130);
    // 下部に指定pxの余裕を持たせる
    const maxY = Math.max(10, (rect.height || 300) - 130 - BOTTOM_PADDING);

    const posX = Math.random() * maxX;
    const posY = Math.random() * maxY;

    makeItemDraggable(itemEl, itemData, { x: Math.max(10, posX), y: Math.max(10, posY) }, spawnArea);
    spawnArea.appendChild(itemEl);
  }
}

function makeItemDraggable(itemEl, itemData, initialPos, container) {
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };

  itemEl.style.left = `${initialPos.x}px`;
  itemEl.style.top = `${initialPos.y}px`;

  itemEl.addEventListener('pointerdown', (e) => {
    isDragging = true;
    itemEl.setPointerCapture(e.pointerId);
    itemEl.classList.add('dragging');

    const rect = itemEl.getBoundingClientRect();
    dragOffset.x = e.clientX - rect.left;
    dragOffset.y = e.clientY - rect.top;
  });

  itemEl.addEventListener('pointermove', (e) => {
    if (!isDragging) return;
    const containerRect = container.getBoundingClientRect();
    itemEl.style.left = `${e.clientX - containerRect.left - dragOffset.x}px`;
    itemEl.style.top = `${e.clientY - containerRect.top - dragOffset.y}px`;
  });

  const handlePointerEnd = (e) => {
    if (!isDragging) return;
    isDragging = false;
    itemEl.classList.remove('dragging');

    try { itemEl.releasePointerCapture(e.pointerId); } catch (err) {}

    const itemRect = itemEl.getBoundingClientRect();
    const itemCenter = { x: itemRect.left + itemRect.width / 2, y: itemRect.top + itemRect.height / 2 };

    let matchedZone = null;
    document.querySelectorAll('.target-zone').forEach(zone => {
      const zRect = zone.getBoundingClientRect();
      if (itemCenter.x >= zRect.left && itemCenter.x <= zRect.right &&
          itemCenter.y >= zRect.top && itemCenter.y <= zRect.bottom) {
        matchedZone = zone;
      }
    });

    if (matchedZone) {
      const catName = matchedZone.dataset.category;
      if (itemData.tags.includes(catName)) {
        playSound('success');
        itemEl.style.pointerEvents = 'none';
        matchedZone.querySelector('.zone-items').appendChild(itemEl);

        currentGame.activeOnScreen = currentGame.activeOnScreen.filter(it => it !== itemData);
        currentGame.completedCount++;
        currentGame.sessionTotalPlaced++;
        document.getElementById('progress-display').textContent = `${currentGame.completedCount} / ${currentGame.targetTotalCount}`;

        if (currentGame.completedCount >= currentGame.targetTotalCount) {
          setTimeout(() => {
            playSound('clear');
            handleQuestionCompleted();
          }, 300);
        } else {
          fillSpawnArea();
        }
      } else {
        currentGame.sessionMistakes++;
        playSound('error');

        const containerRect = container.getBoundingClientRect();
        // 間違えた時の戻り位置も下端から80px上げる
        const BOTTOM_PADDING = 80;
        const bottomY = Math.max(10, containerRect.height - 130 - BOTTOM_PADDING);
        
        itemEl.style.transition = 'top 0.2s ease-out, left 0.2s ease-out';
        itemEl.style.top = `${bottomY}px`;

        setTimeout(() => {
          itemEl.style.transition = '';
        }, 200);
      }
    }
  };

  itemEl.addEventListener('pointerup', handlePointerEnd);
  itemEl.addEventListener('pointercancel', handlePointerEnd);
}

// 1問完了時の判定処理
function handleQuestionCompleted() {
  const container = document.createElement('div');
  container.className = 'next-btn-container';
  // ボタンの位置を下端から80px浮かせた位置に中央配置
  container.style.cssText = `
    position: absolute;
    left: 50%;
    bottom: 80px;
    transform: translateX(-50%);
    z-index: 100;
  `;

  const btn = document.createElement('button');
  btn.className = 'btn-main';

  if (currentGame.currentQuestionIndex < currentGame.totalQuestions) {
    btn.textContent = 'つぎへ';
    btn.onclick = () => {
      container.remove();
      currentGame.currentQuestionIndex++;
      setupSingleQuestion();
    };
  } else {
    btn.textContent = 'ホームへ';
    btn.onclick = () => {
      container.remove();
      recordHistory();
      returnToHome();
    };
  }

  container.appendChild(btn);
  document.getElementById('screen-game').appendChild(container);
}

// 履歴の記録
async function recordHistory() {
  const now = new Date();
  const dateStr = `${now.getFullYear()}/${now.getMonth()+1}/${now.getDate()} ${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
  
  const historyEntry = {
    date: dateStr,
    questionsCompleted: currentGame.totalQuestions,
    totalImagesPlaced: currentGame.sessionTotalPlaced,
    mistakes: currentGame.sessionMistakes
  };

  await dbAddHistory(historyEntry);
}

// 履歴トリプルタップ処理
let historyTapTimes = [];
document.getElementById('btn-history-trigger').addEventListener('pointerdown', (e) => {
  e.preventDefault();
  const now = Date.now();
  historyTapTimes.push(now);
  historyTapTimes = historyTapTimes.filter(t => now - t <= 600);

  if (historyTapTimes.length >= 3) {
    historyTapTimes = [];
    document.getElementById('modal-history').classList.remove('hidden');
    renderHistoryUI();
  }
});

document.getElementById('btn-close-history').addEventListener('click', () => {
  document.getElementById('modal-history').classList.add('hidden');
});

document.getElementById('btn-clear-history').addEventListener('click', async () => {
  if (confirm("履歴をすべて削除しますか？")) {
    await dbClearHistory();
    await renderHistoryUI();
  }
});

async function renderHistoryUI() {
  const histories = await dbGetStore('history');
  const listEl = document.getElementById('history-list');
  listEl.innerHTML = '';

  if (histories.length === 0) {
    listEl.innerHTML = '<p style="text-align:center; color:#888; padding:20px;">まだ履歴がありません。</p>';
    return;
  }

  histories.reverse().forEach(h => {
    const card = document.createElement('div');
    card.className = 'history-card';
    card.innerHTML = `
      <div class="history-date">${h.date}</div>
      <div class="history-stats">解いた問題数: ${h.questionsCompleted} 問</div>
      <div class="history-detail">
        分けたイラスト数: <strong>${h.totalImagesPlaced}</strong> 個 / 間違えた回数: <strong style="color:${h.mistakes > 0 ? '#e03131' : '#2b8a3e'}">${h.mistakes}</strong> 回
      </div>
    `;
    listEl.appendChild(card);
  });
}

// 設定トリプルタップ処理
let settingsTapTimes = [];
document.getElementById('btn-settings-trigger').addEventListener('pointerdown', (e) => {
  e.preventDefault();
  const now = Date.now();
  settingsTapTimes.push(now);
  settingsTapTimes = settingsTapTimes.filter(t => now - t <= 600);

  if (settingsTapTimes.length >= 3) {
    settingsTapTimes = [];
    openSettings();
  }
});

function openSettings() {
  document.getElementById('modal-settings').classList.remove('hidden');
  renderSettings();
}

function closeSettingsModal() {
  saveData();
  document.getElementById('modal-settings').classList.add('hidden');
}

document.getElementById('btn-close-settings').addEventListener('click', closeSettingsModal);
document.getElementById('btn-back-play-config').addEventListener('click', closeSettingsModal);

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', (e) => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');

    const targetTab = e.target.dataset.tab;
    ['tab-play-config', 'tab-categories', 'tab-items', 'tab-data'].forEach(id => {
      document.getElementById(id).classList.toggle('hidden', id !== targetTab);
    });
  });
});

function updateConfigUI() {
  document.querySelectorAll('input[name="cfg-cat-count"]').forEach(radio => {
    radio.checked = (parseInt(radio.value) === appState.config.categoryCount);
  });

  document.querySelectorAll('input[name="cfg-visible-count"]').forEach(radio => {
    radio.checked = (parseInt(radio.value) === appState.config.maxVisibleItems);
  });

  document.getElementById('cfg-total-count').value = appState.config.totalItemsPerQuestion;
  document.getElementById('val-total-count').textContent = appState.config.totalItemsPerQuestion === 0 ? "全部" : appState.config.totalItemsPerQuestion;

  document.getElementById('cfg-question-count').value = appState.config.questionCount;
  document.getElementById('val-question-count').textContent = appState.config.questionCount;

  document.getElementById('cfg-show-home').checked = appState.config.showHomeButton;
}

// 設定入力イベントハンドラ
document.querySelectorAll('input[name="cfg-cat-count"]').forEach(radio => {
  radio.addEventListener('change', (e) => {
    appState.config.categoryCount = parseInt(e.target.value);
  });
});

document.querySelectorAll('input[name="cfg-visible-count"]').forEach(radio => {
  radio.addEventListener('change', (e) => {
    appState.config.maxVisibleItems = parseInt(e.target.value);
  });
});

document.getElementById('cfg-total-count').addEventListener('input', (e) => {
  const val = parseInt(e.target.value);
  appState.config.totalItemsPerQuestion = val;
  document.getElementById('val-total-count').textContent = val === 0 ? "全部" : val;
});

document.getElementById('cfg-question-count').addEventListener('input', (e) => {
  const val = parseInt(e.target.value);
  appState.config.questionCount = val;
  document.getElementById('val-question-count').textContent = val;
});

document.getElementById('cfg-show-home').addEventListener('change', (e) => {
  appState.config.showHomeButton = e.target.checked;
});

function renderSettings() {
  const catList = document.getElementById('category-list');
  catList.innerHTML = '';
  appState.categories.forEach((cat, idx) => {
    const row = document.createElement('div');
    row.className = 'setting-row';

    const iconPreviewEl = createCategoryIconElement(cat);

    const leftContainer = document.createElement('div');
    leftContainer.style.cssText = 'display:flex; align-items:center; gap:10px; flex-wrap:wrap;';

    const colorPicker = document.createElement('input');
    colorPicker.type = 'color';
    colorPicker.value = cat.color;
    colorPicker.onchange = (e) => {
      appState.categories[idx].color = e.target.value;
      renderSettings();
    };

    const nameSpan = document.createElement('span');
    nameSpan.style.cssText = 'font-weight:bold; min-width:80px;';
    nameSpan.textContent = cat.name;

    const iconBox = document.createElement('div');
    iconBox.style.cssText = 'display:flex; align-items:center; gap:6px;';
    iconBox.appendChild(iconPreviewEl);

    const fileLabel = document.createElement('label');
    fileLabel.className = 'btn-sub';
    fileLabel.style.cssText = 'padding: 2px 8px; font-size: 0.85rem; cursor:pointer;';
    fileLabel.textContent = '変更';
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.className = 'hidden';
    fileInput.onchange = (e) => updateCategoryIcon(idx, e.target);
    fileLabel.appendChild(fileInput);
    iconBox.appendChild(fileLabel);

    if (cat.icon) {
      const delBtn = document.createElement('button');
      delBtn.className = 'btn-sub';
      delBtn.style.cssText = 'padding: 2px 6px; font-size:0.8rem;';
      delBtn.textContent = '削除';
      delBtn.onclick = () => removeCategoryIcon(idx);
      iconBox.appendChild(delBtn);
    }

    leftContainer.appendChild(colorPicker);
    leftContainer.appendChild(nameSpan);
    leftContainer.appendChild(iconBox);

    const rightContainer = document.createElement('div');
    rightContainer.innerHTML = `
      <label style="margin-right:12px;">
        <input type="checkbox" ${cat.enabled ? 'checked' : ''} onchange="appState.categories[${idx}].enabled = this.checked"> 使用
      </label>
      <button class="btn-sub" style="color:red; padding:4px 8px;" onclick="deleteCategory(${idx})">削除</button>
    `;

    row.appendChild(leftContainer);
    row.appendChild(rightContainer);
    catList.appendChild(row);
  });

  const itemList = document.getElementById('item-list');
  itemList.innerHTML = '';
  appState.items.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = 'setting-row';

    const visualHTML = item.type === 'image' 
      ? `<img src="${item.value}" style="width:40px; height:40px; object-fit:contain;">`
      : `<span style="font-size:2rem;">${item.value}</span>`;

    let tagCheckboxesHTML = appState.categories.map(c => `
      <label style="font-size:0.85rem; margin-right:6px;">
        <input type="checkbox" ${item.tags.includes(c.name) ? 'checked' : ''} 
               onchange="toggleItemTag(${idx}, '${c.name}', this.checked)"> ${c.name}
      </label>
    `).join('');

    row.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px; flex:1;">
        ${visualHTML}
        <span style="font-weight:bold; min-width:80px;">${item.name}</span>
        <div style="display:flex; flex-wrap:wrap;">${tagCheckboxesHTML}</div>
      </div>
      <button class="btn-sub" style="color:red; padding:4px 8px;" onclick="deleteItem(${idx})">削除</button>
    `;
    itemList.appendChild(row);
  });

  const tagsContainer = document.getElementById('new-item-tags');
  tagsContainer.innerHTML = '';
  appState.categories.forEach(cat => {
    const label = document.createElement('label');
    label.innerHTML = `<input type="checkbox" value="${cat.name}"> ${cat.name}`;
    tagsContainer.appendChild(label);
  });
}

window.updateCategoryIcon = function(idx, inputEl) {
  const file = inputEl.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      appState.categories[idx].icon = e.target.result;
      renderSettings();
    };
    reader.readAsDataURL(file);
  }
};

window.removeCategoryIcon = function(idx) {
  appState.categories[idx].icon = "";
  renderSettings();
};

window.toggleItemTag = function(itemIdx, catName, isChecked) {
  const tags = appState.items[itemIdx].tags;
  if (isChecked) {
    if (!tags.includes(catName)) tags.push(catName);
  } else {
    appState.items[itemIdx].tags = tags.filter(t => t !== catName);
  }
};

window.deleteCategory = function(idx) {
  appState.categories.splice(idx, 1);
  renderSettings();
};

window.deleteItem = function(idx) {
  appState.items.splice(idx, 1);
  renderSettings();
};

let newCatIconBase64 = "";
document.getElementById('new-cat-icon-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (evt) => {
      newCatIconBase64 = evt.target.result;
      document.getElementById('cat-icon-preview').innerHTML = `<img src="${newCatIconBase64}" style="width:40px;height:40px;object-fit:contain;margin-top:8px;">`;
    };
    reader.readAsDataURL(file);
  }
});

document.getElementById('btn-add-category').addEventListener('click', () => {
  const nameInput = document.getElementById('new-cat-name');
  const colorInput = document.getElementById('new-cat-color');
  const name = nameInput.value.trim();

  if (name) {
    appState.categories.push({ id: Date.now(), name, color: colorInput.value, icon: newCatIconBase64, enabled: true });
    nameInput.value = '';
    newCatIconBase64 = '';
    document.getElementById('cat-icon-preview').innerHTML = '';
    renderSettings();
  }
});

function toggleInputType(type) {
  document.getElementById('form-emoji').classList.toggle('hidden', type !== 'emoji');
  document.getElementById('form-image').classList.toggle('hidden', type !== 'image');
}

document.getElementById('btn-add-item').addEventListener('click', async () => {
  const inputType = document.querySelector('input[name="input-type"]:checked').value;
  const selectedTags = [];
  document.querySelectorAll('#new-item-tags input:checked').forEach(cb => selectedTags.push(cb.value));

  if (inputType === 'emoji') {
    const emoji = document.getElementById('new-item-emoji').value.trim();
    const name = document.getElementById('new-item-name-emoji').value.trim();
    if (emoji && name) {
      appState.items.push({ id: Date.now(), name, type: 'emoji', value: emoji, tags: selectedTags });
      document.getElementById('new-item-emoji').value = '';
      document.getElementById('new-item-name-emoji').value = '';
      renderSettings();
    }
  } else {
    const files = document.getElementById('new-item-files').files;
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const base64 = await fileToBase64(file);
        const name = file.name.replace(/\.[^/.]+$/, "");
        appState.items.push({ id: Date.now() + i, name, type: 'image', value: base64, tags: [...selectedTags] });
      }
      document.getElementById('new-item-files').value = '';
      renderSettings();
    }
  }
});

function fileToBase64(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target.result);
    reader.readAsDataURL(file);
  });
}

document.getElementById('btn-export-json').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(appState, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'category_classify_backup.json';
  a.click();
});

document.getElementById('file-import-json').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (evt) => {
    try {
      const imported = JSON.parse(evt.target.result);
      if (imported.categories && imported.items) {
        appState = imported;
        await saveData();
        renderSettings();
        updateConfigUI();
        alert("データを正常に復元しました。");
      }
    } catch (err) {
      alert("JSONファイルの読み込みに失敗しました。");
    }
  };
  reader.readAsText(file);
});

document.getElementById('btn-reset-default').addEventListener('click', async () => {
  if (confirm("初期状態に戻しますか？")) {
    appState.categories = [...defaultCategories];
    appState.items = [...defaultItems];
    await saveData();
    renderSettings();
    updateConfigUI();
  }
});

loadData();